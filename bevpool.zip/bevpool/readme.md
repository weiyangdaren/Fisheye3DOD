## install

cd ~/bevpool

pip install -e .

cd ~/bevpool/bev_pool

python3 bev_pool.py